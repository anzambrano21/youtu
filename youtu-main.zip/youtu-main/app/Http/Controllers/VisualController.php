<?php

namespace App\Http\Controllers;

use App\Models\visual;
use Illuminate\Http\Request;

class VisualController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\visual  $visual
     * @return \Illuminate\Http\Response
     */
    public function show(visual $visual)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\visual  $visual
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, visual $visual)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\visual  $visual
     * @return \Illuminate\Http\Response
     */
    public function destroy(visual $visual)
    {
        //
    }
}
